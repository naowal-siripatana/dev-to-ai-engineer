# Safety notes

Disconnect the power cable before you open the casing. Install the unit away from water spray and direct sunlight. Operating temperature is 0 to 45 degrees Celsius. Only trained staff should replace the battery.
