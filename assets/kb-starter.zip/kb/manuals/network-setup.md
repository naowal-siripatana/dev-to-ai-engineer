# Network setup guide

Choose Settings, then Network, and pick your Wi-Fi name. Enter the password and wait for the light to turn solid green. The monitor works on 2.4 GHz networks only. If the network is lost, readings are stored on the unit and sent later.
