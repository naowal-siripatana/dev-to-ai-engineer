# Firmware update guide

Open Settings, choose Firmware, and press Check for updates. Keep the monitor plugged in during the update, which takes about five minutes. Do not unplug the unit while the light blinks blue.
