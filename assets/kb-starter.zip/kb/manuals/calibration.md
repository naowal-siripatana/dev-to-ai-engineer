# Calibration guide

Calibrate the sensor once a month. Open the menu, choose Calibrate, and keep the pump running at normal speed for two minutes. The monitor stores the new values and shows the date of the last calibration on the home screen.
