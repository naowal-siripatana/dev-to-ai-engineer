# Installation guide

Mount the PumpGuard monitor on a flat wall near the pump, at eye level. Use the four screws from the box. Connect the sensor cable first and the power cable last. The status light turns green when the unit is ready.
