# Maintenance guide

Wipe the casing with a dry cloth every month. Do not use water or cleaning spray near the sensor port. Check the sensor cable for cracks every three months and replace it if the outer layer is damaged.
