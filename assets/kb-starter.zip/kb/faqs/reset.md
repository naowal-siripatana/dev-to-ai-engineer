# How do I reset the monitor?

Hold the power button for 5 seconds until the light blinks. This restarts the unit and keeps your settings. To restore factory settings, hold the button for 15 seconds.
