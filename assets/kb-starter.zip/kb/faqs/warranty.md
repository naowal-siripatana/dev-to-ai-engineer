# What does the warranty cover?

The monitor has a two year warranty on manufacturing faults. It does not cover water damage or a cracked sensor cable. Keep your receipt and the serial number.
