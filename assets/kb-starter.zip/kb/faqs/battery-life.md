# How long does the battery last?

A full charge lasts about 8 hours without mains power. Charge the monitor overnight for best results. The battery should be replaced after about three years.
