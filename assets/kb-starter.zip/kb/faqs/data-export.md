# Can I export my readings?

Yes. Open the web dashboard, choose Readings, and press Export. You get a CSV file with the time, pressure and temperature of each reading for the last 90 days.
