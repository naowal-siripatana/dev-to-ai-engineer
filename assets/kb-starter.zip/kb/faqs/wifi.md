# Why does the monitor not find my Wi-Fi?

The monitor supports 2.4 GHz networks only. Move it closer to the router and check that the network name has no special characters. Restart the monitor and try again.
