# Where is the serial number?

The serial number is on the label under the device, and on the About screen in Settings. You need it for support requests and for the warranty.
