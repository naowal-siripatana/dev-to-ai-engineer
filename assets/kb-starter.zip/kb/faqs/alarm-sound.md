# How do I turn the alarm sound off?

Open Settings, choose Sound, and set the alarm to Silent. The light still turns red when there is a problem. We do not recommend silencing the alarm on pumps that run unattended.
